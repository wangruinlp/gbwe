/*
 * MATLAB Compiler: 2.0
 * Date: Fri Nov 05 13:55:48 1999
 * Arguments: "-m" "-v" "cluster.m" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __inconsistent_h
#define __inconsistent_h 1

#include "matlab.h"

extern mxArray * mlfInconsistent(mxArray * Z, mxArray * depth);
extern void mlxInconsistent(int nlhs,
                            mxArray * plhs[],
                            int nrhs,
                            mxArray * prhs[]);

#endif
