/*         exit_if.h         du 26 juin 98         */

#ifndef EXIT_IF_H
#define EXIT_IF_H

#define EXIT_IF(expression, message) \
exit_if(__FILE__, __LINE__, expression, #expression, message)

#define PERROR_AND_EXIT() \
     perror_and_exit1(__FILE__ ":" PERROR__STRING(__LINE__) ":")
#define PERROR_STRING(n) PERROR___STRING(n)
#define PERROR___STRING(n) #n

extern void exit_if(char *fichier, int ligne, int condition,
		    char *code, char *message);
extern char *exit_message;
extern void perror_and_exit1(char *localisation);

#endif /* EXIT_IF */
