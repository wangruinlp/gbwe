#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "add_accent.h"
/**
 *  making possible search words such as "garcon+velo+inferieur" by converting "gar�on+v�lo+inf�rieur"
 **/
void add_accent( FILE *fp, const char *msg, const char **V, int nv, const char *v, const char *bg, int nw, const char *dico_ext, const char *program_name )
{
	return;
}
