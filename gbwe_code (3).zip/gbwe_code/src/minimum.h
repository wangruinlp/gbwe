/* minimum.h */

#ifndef MINIMUM_H
#define MINIMUN_H

int minimum( int ligne, int colonne, int compo );

#endif /* MINIMUM */
