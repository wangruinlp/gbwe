#include <stdio.h>
#include "messhtml.h"
#include "../commun/URL.h"
#include "../commun/print_homepage.h"
#include "../commun/print_garde.h"

void write_html_nouvelle_req()
//void write_html_nouvelle_req(const char* source_langue)
{
        printf("\n<TABLE COLS=2 BORDER=0> <TR>");
		//		if(source_langue[0]=='F')
        	printf("<TH WIDTH=80 HEIGHT=50 ALIGN=CENTER><A HREF=\"/dico/en/chercher\">");
		//		else
       // 	printf("<TH WIDTH=80 HEIGHT=50 ALIGN=CENTER><A HREF=\"/dico/en/chercher\">");
        printf("<IMG SRC=\"%squestion.gif\" HSPACE=5 HEIGHT=40 WIDTH=40 BORDER=0></A></TH> <TD WIDTH=300><B><A HREF=\"/dico/en/chercher\">Nouvelle requ�te</A></B></TD> </TR> </TABLE>\n </BODY>",ImageURL);
}

void write_html_erreur_interne(const char *mess)
{
       printf("<HEAD><TITLE>Erreur interne</TITLE></HEAD>\n <BODY TEXT=\"#000000\" BACKGROUND=\"%sfond_err.gif\">\n <BR> <B>D�sol�, le serveur a rencontr� une erreur interne qui le rend incapable de satisfaire � votre requ�te.</B> <BR><BR> <U>Code erreur</U> : %s <BR><BR> Merci de nous informer si vous constatez des dysfonctionnements r�p�t�s: <FONT SIZE=+1><B><I>&nbsp;&nbsp; </I></B><A HREF=\"mailto:dico@isc.cnrs.fr\">dico@isc.cnrs.fr</A></FONT> <BR><BR><BR>",ImageURL,mess);         
       print_garde();
       write_html_nouvelle_req();        
       printf("</BODY>");
}

void write_html_req_invalide()
{
     printf("<HEAD><TITLE>Req�te invalide</TITLE></HEAD>\n <BODY TEXT=\"#000000\" BACKGROUND=\"%sfond_err.gif\">\n <H1>Req�te invalide</H1><P><HR>\n <BR> <B>La syntaxe de la requ�te est incorrecte.</B><BR><BR> <BR><BR><BR>",ImageURL); print_garde(); write_html_nouvelle_req();                 printf("</BODY>");
}


void write_html_new_search()
//void write_html_new_search(const char * source_langue)
{
        printf("\n<TABLE COLS=2 BORDER=0>
        <TR>");
			//	if(source_langue[0]=='F')
        	printf("<TH WIDTH=80 HEIGHT=50 ALIGN=CENTER><A HREF=\"/dico/en/search\">");
			//	else
        	//printf("<TH WIDTH=80 HEIGHT=50 ALIGN=CENTER><A HREF=\"/dico/en/chercher\">");
        printf("<IMG SRC=\"%squestion.gif\" HSPACE=5 HEIGHT=40 WIDTH=40 BORDER=0></A></TH> <TD WIDTH=300><B><A HREF=\"/dico/en/search\">New Search</A></B></TD> </TR> </TABLE>\n </BODY>",ImageURL);
}


void write_html_internal_error(const char *mess)
{
       printf("<HEAD><TITLE>Internal Sever Error</TITLE></HEAD>\n <BODY TEXT=\"#000000\" BACKGROUND=\"%sfond_err.gif\">\n <BR><B>An internal sever error appeared on the ISC server.</B> <BR><BR> <U>Error code</U> : %s <BR><BR> Thank you for informing us about repeated malfunctions: <FONT SIZE=+1><B><I>&nbsp;&nbsp; </I></B><A HREF=\"mailto:dico@isc.cnrs.fr\">dico@isc.cnrs.fr</A></FONT> <BR><BR><BR>",ImageURL,mess);         
       print_homepage();
       //write_html_new_search();        
       //printf("</BODY>");
}

void write_html_invalid_req()
{
     printf("<HEAD><TITLE>Invalid Instruction</TITLE></HEAD>\n <BODY TEXT=\"#000000\" BACKGROUND=\"%sfond_err.gif\">\n <H1>Invalid Instruction</H1><P><HR>\n <BR> <B>The request is not well formed.</B><BR><BR> <BR><BR><BR>",ImageURL);
     print_homepage();
//     write_html_nouvelle_req();                 
//     printf("</BODY>");
}

