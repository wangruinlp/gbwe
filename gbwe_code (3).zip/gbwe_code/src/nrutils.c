/* nrutils.c */
/* routine pour allouer une matrice m[nrl..nrh][ncl..nch] */


#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#define NR_END 1


double **dmatrix(int nrl, int nrh, int ncl, int nch)
{
  int i, nrow=nrh-nrl+1, ncol=nch-ncl+1;
  double **m;
  
  /* allouer les pointeurs aux lignes */
  m=(double **) malloc((size_t)((nrow+NR_END)*sizeof(double*)));
  if (!m)
    {
    }
  m += NR_END;
  m -= nrl;

  /* allouer les lignes et faire pointer les pointeurs dessus */
  m[nrl]=(double *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(double)));
  if (!m[nrl]) {}
  m[nrl] += NR_END;
  m[nrl] -= ncl;
  
  for(i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;
  
  /* retourne un pointeur vers un tableau de lignes */
  return m;
}
