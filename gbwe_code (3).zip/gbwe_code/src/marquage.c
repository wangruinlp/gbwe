/* marquage.c */

#include <stdlib.h>
#include "pilegen.h"
#include "marquage.h"

int marquage( int sommet, int niveau,int taille, int GAMA[],pilegen pile_e1, double **NTN, int compteur )
{
  int j;
  int *entier;
  
  if (compteur == 0) 
    {
/*        printf("compteur nul\n"); */
      return compteur;
    }
  for( j = 1 ; j <= taille ; j ++ )
    {
      if ( NTN[sommet][j] != 0)
	{
	  if ( GAMA[j] == -1 )
	    {
	      GAMA[j] = niveau;
	      entier = malloc(sizeof(int));
	      *entier = j;
	      pilegen_empiler(pile_e1,entier);
	      compteur --;
	      if (compteur == 0) break;
	    }
	  if (compteur == 0)
	    {
/*  	      printf("compteur nul\n"); */
	      return compteur;
	    }
	}
      if (compteur == 0) break;
    }
  return compteur;
}

