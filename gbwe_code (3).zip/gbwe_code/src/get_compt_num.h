char * get_compt_num(char *, const char *);
