int getSynLine(const char* , char* , const char *);
//int getSynLine(const char* word, char* line, const char *base);
//copie dans la chaine 'line', la ligne du dictionnaire associ�e au mot 'word'
//#define MaxLine 10000
//#define	 MAX_word_len 255
//#define	 MAX_line_len 1023
