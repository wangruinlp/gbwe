#include "getQueries.h"
int 
getQueries(Query *qry, const char *s)
{
	char **tokens;
	extern int max_queries;
	extern int maxqlen;
	int nw;
	int i;

	tokens=cmatrix(0, max_queries, 0, maxqlen);
	nw=toTokens(tokens,s,'&',max_queries);
	for(i=0;i<nw;i++)
	{
		ncopy(qry[i].key,tokens[i],'=');
		//nrcopy(qry[i].key,tokens[i],'=');
		ncopyn(qry[i].value,tokens[i],'=','&');
	}
	free_cmatrix(tokens,0,max_queries, 0, maxqlen);
	return nw;
}
