#include <stdlib.h>
#define NR_END 1
#define FREE_ARG char*
#define NULL 0

void free_cmatrix( char **m, int nrl, int nrh, int ncl, int nch)
/* free an int matrix allocated by imatrix() */
{
//	if(m==NULL)
//		return;
        free((FREE_ARG) (m[nrl]+ncl-NR_END));
        free((FREE_ARG) (m+nrl-NR_END));
}
