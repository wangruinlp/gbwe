int countTokens( const char *s, const char v);
