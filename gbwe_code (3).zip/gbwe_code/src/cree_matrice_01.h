/* cree_matrice_01.h */

#ifndef CREE_MATRICE_01_H
#define CREE_MATRICE_O1_H

void cree_matrice(vecteur v,double **m02,int ligne,int colonne);

#endif  /* CREE_MATRICE_01_H */
