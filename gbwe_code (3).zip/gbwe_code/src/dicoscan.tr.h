#define MaxLine 10000

void getSynLine(char* word,char* line,char *base); //copie dans la chaine 'line', la ligne du dictionnaire associ�e au mot 'word'
