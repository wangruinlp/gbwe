#include <stdlib.h>
#define NR_END 1
#define FREE_ARG char*

free_ivector(int *v, long nl, long nh)
/* free an int vector allocated with ivector() */
{
//	if(v==NULL)
//		return;
        free((FREE_ARG) (v+nl-NR_END));
}

