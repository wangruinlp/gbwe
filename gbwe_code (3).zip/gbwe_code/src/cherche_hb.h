#ifndef CHERCHE_HB_H
#define CHERCHE_HB_H

void cherche_hb(double Ae[],int lig,pilegen pile_e1,pilegen pile_e2);

#endif  /* CHERCHE_HB_H  */
