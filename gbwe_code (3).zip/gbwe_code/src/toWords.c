#include <string.h>
int 
toWords( char **t, const char *s, const char v, int dico)
{ 
	register int i = 0; 
	register const char *p=s;
	register char *q;
	int n=0;
	q=t[0];
	if(dico)
	{
		while (*p!=v)
			*q++ = *p++;
		*q='\0';
		n++;
		q= t[++i];
		p+=3;
	}
	while (*p)
	{
	      if(*p==v)
	      {
		      *q='\0';
		      n++;
		      q= t[++i];
		      p++;
	      }
	      else 
		      *q++ = *p++;
	}
	*q='\0';
	if(*(--p)!=v && strlen(t[n])>0)
		n++;
	return n;
}
