/* matrice_khi2.h */

#ifndef MATRICE_KHI2_H
#define MATRICE_KHI2_H

void matrice_khi2(double **m01,double **m02,double D1[],double D2[],int ligne,int colonne);

#endif /* MATRICE_KHI2_H */
