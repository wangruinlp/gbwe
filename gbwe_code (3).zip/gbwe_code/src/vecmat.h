#define NR_END 1
#define FREE_ARG char*
