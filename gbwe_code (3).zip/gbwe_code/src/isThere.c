#include <string.h>
int isThere(const char ** lists, const char *s)
{
	int i=0;
	while(lists[i][0]!='#')
		if(strcmp(s,lists[i++])==0)
			return i;
	return 0;
}
