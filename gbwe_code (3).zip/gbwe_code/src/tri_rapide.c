/* tri_rapide.c */

#include "tri_rapide.h"

void tri_rapide(int Ax[],double Ae[], int p , int r)
{
  int q;
  if ( p < r )
    {
      q = partionner(Ax,Ae,p,r);
      tri_rapide(Ax,Ae,p,q);
      tri_rapide(Ax,Ae,q+1,r);
    }
}

int partionner(int Ax[],double Ae[], int p, int r)
{
  double x;
  double valeur;
  int i,j;
  int indice;


  x = Ae[(p-1)*2];
  i = p-1;
  j = r+1;
  for(;;)
    {
      do
	{
	  j = j - 1;
	} while (Ae[(j-1)*2] > x);
      do
	{
	  i = i + 1;
	} while (Ae[(i-1)*2] < x);
      if ( i < j )
	{
	  valeur = Ae[(i-1)*2];
	  Ae[(i-1)*2] = Ae[(j-1)*2];
	  Ae[(j-1)*2] = valeur;
	  valeur = Ae[(i-1)*2+1];
	  Ae[(i-1)*2+1] = Ae[(j-1)*2+1];
	  Ae[(j-1)*2+1] = valeur;
	  indice = Ax[i-1];
	  Ax[i-1] = Ax[j-1];
	  Ax[j-1] = indice;
	}
      else
	return j;
    }
}
