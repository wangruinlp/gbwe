#include "utils.h"
//#include "URLHTML.h"
//#include "../commun/text/text_noentry.h"
#define MAX_WORD_LEN 256
#define MAX_WORDHREF_LEN 256
void getNewWord(char* t, char* t2, const char *s, const char *program);
void add_accent( FILE *fp, const char *msg, const char **V, int nv, const char *v, const char *bg, int nw, const char *dico_ext, const char *program_name );
