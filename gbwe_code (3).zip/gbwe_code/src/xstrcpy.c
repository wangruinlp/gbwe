/**
 * xstrcpy(to,"gar%E7on");
 * == strcpy(to,"gar�on");
 * xstrcpy(to,"gar%E7on%2Bfille");
 * == strcpy(to,"gar�on+fille");
 * xstrcpy(to,"+gar%E7on+%2B++%2B+++fille%2B%2B+++%2B++");
 * == strcpy(to,"gar�on+fille");
 *
 * CAUTION : this does not examine whether the length of "t" is too short or not. 
 * 
 * */
int xstrcpy(char * t, const char *s)
{
	register char *q=t;
	register const char *p=s;
	char str[4];
	int n=1;
        int c=0;
	while(*p)
	{
		if(*p=='%')
		{
                	//conversion de %xx en le caract�re corresqondant
			p++;
                	str[0]= *p++;str[1]= *p++; str[2]=0;
                	sscanf(str,"%x",&c);
			if(c=='+')
			{
				if(q==t)
					continue;
				n++;
				q--;
				while(*q==' ') //skiq surqlus ' 's
					q--;
				while(*q=='+') //skiq surqlus +
					q--;
				q++;
				*q++ = '+';
				while(*p == '+' && *p)  //skiq surqlus ' 's
					p++;
			}
			else
				*q++ = c;
		}
		else if(*p=='+')
		{
			p++;
			if(q==t)
				continue;
			else if(*(q-1) == ' ')
				continue;
			else
				*q++ = ' ';
		}
		else
			*q++ = *p++;

	}
	q--;
	while(*q==' ')
		q--;
	while(*q=='+')
		q--;
	*++q = '\0';
	return n;
}
