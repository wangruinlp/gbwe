/**
 * ncopyn(to,"this=that&", '=', '&');
 * == strcpy(to,"that");
 *
 * CAUTION : this does not examine whether the length of "t" is too short or not. 
 */
int ncopyn (char * t, const char *s, const char from, const char to)
{
	register char *q=t;
	register const char *p=s;
	while( *p!=from && *p)
		p++;
	p++;
	while(*p)
	{
		if(*p==to)
			break;
		*q++ = *p++;
	}
	*q = 0;
	if(*p==0)
		return -1;
	else
		return q-t;
}
