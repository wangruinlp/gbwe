/* tred2.h */
#ifndef TRED2_H
#define TRED2_H

void tred2(double **a, int n, double d[], double e[]);

#endif /* TRED2_H */
