/*   fonctions_pile.h  */

#ifndef FONCTIONS_PILE_H
#define FONCTIONS_PILE_H

void creer_pile(int PILE[],int taille);
int depile(int PILE[],int taille);
int pile_vide(int PILE[]);
int empile( int sommet, int PILE[], int taille );
int sommet(int PILE[],int taille);

#endif /* FONCTIONS_PILE_H */
