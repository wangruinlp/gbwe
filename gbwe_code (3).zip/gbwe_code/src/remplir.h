/* remplir.h */

#ifndef REMPLIR_H
#define REMPLIR_H

void rempli(double *vect,int taille,double valeur);
void rempli_i(int *vect,int taille,int valeur);

#endif /* REMPLIR_H */
