#include <stdlib.h>
#include <string.h>
#include <stdio.h>


typedef struct
{
	int* element;
	int nelements;
}cClique;


int main(int argc,char*argv[])
{

    //nom des fichiers
	char synsname[256], synocname[256], trname[256], cliocname[256]; //fichiers d'entree
	char syncname[256], clicname[256], tradname[256];	//fichiers de sortie
	char clisname[256];

	//fichiers
	FILE *fi_syns, *fi_synoc, *fi_tr, *fi_clioc; //fichiers d'entree
	FILE *fo_sync, *fo_clic, *fo_trad; //fichiers de sortie
	FILE *fo_syns, *fo_clis;	//fichiers de sortie des synonymes et cliques du
								//langage source apres tri des traductions (tous
								//ont une traduction

	//variables de synonymes
	typedef char tsynonyme[256];
    tsynonyme *synoc, *syns;
    int nsynoc, nsynoc_orig, nsyns;

	//variables des traductions
    tsynonyme *tr;
    int ntr;

	//variables pour les cliques
	cClique* clioc;
	int nclioc, nclioc_orig;
	int tailleCliqueMax=0;
	int tmptailleclique=0;
	cClique* pcli;
	int num;

	//variables pour la selection des cliques
	int nbtermesEE=2; //nombre de termes dans la clique (matrice TEE)
	int nbtermesFE=3; //nombre de termes traduits par la clique

	//matrices
	int **TFE; //matrice synonymes source x synonymes cible
	int **TEE; //matrice cliques cible x synonymes cible
	int **T_sel; //matrice des syno source x cliques cible
	int *tabsynsup, nbsynsup; //vecteur des syno cibles a supprimer et leur nombre
	int *tabclisup, nbclisup; //vecteur des cliques cibles a supprimer et leur nombre

	//variables pour le tri du langage source
	//tous les synonymes doivent avoir une traduction apres le tri
	//cliques d'entree
	cClique* clis;
	int nclis;
	int **TFF; //matrice cliques source x synonymes source
	cClique* pclis;

    //variables de boucle
    int i, j, k;
    char* ps,* pd;

	//variables temporaires
	char c, str_tmp[1000];
	int somme;


    //test nombre d'arguments
	if (argc!=2)
        {
        printf("\nutilisation : select_tr.exe nom_fichier");
        printf("\nles fichiers g�n�r�s seront nom_fichier.sync, nom_fichier.clic, nom_fichier.trad\n");
        return 0;
        }

	//creation des noms des fichiers d'entree et de sortie
	sprintf(synsname, "%s.syns", argv[1]);  //fichier synonymes langage source
	sprintf(synocname, "%s.synoc", argv[1]);  //fichier synonymes langage cible d'origine
	sprintf(trname, "%s.tr", argv[1]);  //fichier des traductions d'origine
	sprintf(cliocname, "%s.clioc", argv[1]);  //fichier cliques langage cible d'origine
	sprintf(syncname, "%s.sync", argv[1]);  //fichier synonymes langage cible apres tri
	sprintf(clicname, "%s.clic", argv[1]);  //fichier cliques langage cible apres tri
	sprintf(tradname, "%s.trad", argv[1]);  //fichier des traductions apres tri
	sprintf(clisname, "%s.clis", argv[1]);  //fichier cliques langage source apres tri

	//lecture fichier synonymes langage cible
	fi_synoc = fopen(synocname, "rb");
	if (fi_synoc == NULL)
		{ return(-1); }

	//comptage nombre d'entrees du fichier
	nsynoc=0;
	do
		{
		c=fgetc(fi_synoc);
		if (c=='\n')
			{
			nsynoc++;
			}
		}while (!feof(fi_synoc));
    
	nsynoc_orig = nsynoc;

	//stockage des entrees
	synoc = (tsynonyme *)calloc(nsynoc, sizeof(tsynonyme));
	fseek(fi_synoc,0,0);
	for (i=0;i<nsynoc;i++)
		{
		pd=synoc[i];
		do
			{
			(*pd)=c=fgetc(fi_synoc);
			pd++;
			}while ((c!=13)&&(c!=10));
		if (c==13)
			fgetc(fi_synoc);
		pd--;
		(*pd)=0;
		}
	
	fclose(fi_synoc);

	//lecture fichier synonymes langage source
	fi_syns = fopen(synsname, "rb");
	if (fi_syns == NULL)
		{ return(-2); }

	//comptage nombre d'entrees du fichier
	nsyns=0;
	do
		{
		c=fgetc(fi_syns);
		if (c=='\n')
			{
			nsyns++;
			}
		}while (!feof(fi_syns));

	//stockage des entrees
	syns = (tsynonyme *)calloc(nsyns, sizeof(tsynonyme));
	fseek(fi_syns,0,0);
	for (i=0;i<nsyns;i++)
		{
		pd=syns[i];
		do
			{
			(*pd)=c=fgetc(fi_syns);
			pd++;
			}while ((c!=13)&&(c!=10));
		if (c==13)
			fgetc(fi_syns);
		pd--;
		(*pd)=0;
		}
	
	fclose(fi_syns);

	//lecture fichier traduction original
	fi_tr = fopen(trname, "rb");
	if (fi_tr == NULL)
		{ return(-3); }

	//comptage nombre d'entrees du fichier
	ntr=0;
	do
		{
		c=fgetc(fi_tr);
		if (c=='\n')
			{
			ntr++;
			}
		}while (!feof(fi_tr));

	//stockage des entrees
	tr = (tsynonyme *)calloc(ntr, sizeof(tsynonyme));
	fseek(fi_tr,0,0);
	for (i=0;i<ntr;i++)
		{
		pd=tr[i];
		do
			{
			(*pd)=c=fgetc(fi_tr);
			pd++;
			}while ((c!=13)&&(c!=10));
		if (c==13)
			fgetc(fi_tr);
		pd--;
		(*pd)=0;
		}
	
	fclose(fi_tr);

	//allocation matrice syno source x syno cible
	TFE = (int **)calloc(nsyns, sizeof(int *));
	for (i=0; i<nsyns; i++)
	{ TFE[i] = (int *)calloc(nsynoc, sizeof(int)); }

	//initialisation matrice TFE
	for (i=0; i<nsyns; i++)
	{
		//premier mot inutile car langue source
		ps=tr[i];
		while ((*ps)!='\t')
		{
				ps++;
		}
		ps+=3; //on saute "\t:\t"
		while ((*ps)!=0)
		{
			ps+=1; //on saute la lettre d'indication de la langue

			//premier mot langue cible
			pd=str_tmp;
			while ((*ps)!='\t')
			{
					(*pd)=(*ps);
					pd++;
					ps++;
			}
			(*pd)=0;
			ps+=1; //on saute \t

			//verification d'unicite et reclassement
			pd=str_tmp;
			for (j=0;j<nsynoc;j++)
			{
				if (strcmp(synoc[j],pd)==0)
				{
					TFE[i][j]=1;
					break;
				}
			}
		}
	}

	//lecture fichier cliques original langage cible
	fi_clioc = fopen(cliocname, "rb");
	if (fi_clioc == NULL)
		{ return(-4); }
	nclioc = 0;
	do
	{
		c=fgetc(fi_clioc);
		if (c=='\n')
		{
			nclioc++;
			if (tmptailleclique>tailleCliqueMax)
				tailleCliqueMax=tmptailleclique;
			tmptailleclique=0;
		}
		if (c==',')
			tmptailleclique++;
	}while (c!=(char)-1);

    nclioc_orig = nclioc;

	clioc=(cClique*)malloc(sizeof(cClique)*nclioc);
	fseek(fi_clioc,0,0);
	for (i=0;i<nclioc;i++)
	{
		pcli=&clioc[i];
		pcli->element=(int*)malloc(sizeof(int)*tailleCliqueMax);
		pcli->nelements=0;
		num=0;
		do
		{
			c=fgetc(fi_clioc);
			if (c==',')
			{
				pcli->element[pcli->nelements]=num-1;
				num=0;
				pcli->nelements++;
			}
			if ((c>='0') && (c<='9'))
			{
				num=num*10+c-'0';
			}
		}while (c!='\n');
	}

	fclose(fi_clioc);

	//allocation matrice cliques cible x syno cible
	TEE = (int **)calloc(nclioc, sizeof(int *));
	for (i=0; i<nclioc; i++)
	{ TEE[i] = (int *)calloc(nsynoc, sizeof(int)); }

	//initialisation matrice TEE
	for (i=0; i<nclioc; i++)
	{
		for (j=0; j<clioc[i].nelements; j++)
		{ TEE[i][clioc[i].element[j]] = 1; }
	}


	//suppression des cliques dans le langage cible qui contiennent moins de nbtermesEE termes
	nbclisup=0;
	tabclisup=(int *)calloc(nclioc, sizeof(int));
	for (i=0; i<nclioc; i++)
	{
		somme = 0;
		for (j=0; j<nsynoc; j++)
		{ somme += TEE[i][j]; }
		if (somme<nbtermesEE)
		{
			nbclisup++;
			tabclisup[i] = 1;
		}
	}

	if (nbclisup>0)
	{
		for (i=0; i<nclioc; i++)
		{
			if (tabclisup[i]==1)
			{
				for (j=i; j<nclioc-1; j++)
				{
					TEE[j]=TEE[j+1];
					tabclisup[j]=tabclisup[j+1];
				}
				i--;
				nclioc--;
			}
		}
	}
	//desallocations
	free(tabclisup);

	//suppression des synonymes du langage cible n'appartenant plus a aucune clique
	nbsynsup = 0;
	tabsynsup=(int *)calloc(nsynoc, sizeof(int));
	for (i=0; i<nsynoc; i++)
	{
		somme = 0;
		for (j=0; j<nclioc; j++)
		{ somme += TEE[j][i]; }
		if (somme==0)
		{
			nbsynsup++;
			tabsynsup[i] = 1;
		}
	}
	if (nbsynsup>0)
	{
		for (j=0; j<nsynoc; j++)
		{
			if (tabsynsup[j]==1)
			{
				//suppression dans TEE
				for (i=0; i<nclioc; i++)
				{
					for (k=j; k<nsynoc-1; k++)
					{ TEE[i][k]=TEE[i][k+1]; }
				}
				//suppression dans TFE
				for (i=0; i<nsyns; i++)
				{
					for (k=j; k<nsynoc-1; k++)
					{ TFE[i][k]=TFE[i][k+1]; }
				}
				//suppression dans le vecteur des synonymes
				for (k=j; k<nsynoc-1; k++)
				{
					strcpy(synoc[k],synoc[k+1]);
					tabsynsup[k]=tabsynsup[k+1];
				}
				j--;
				nsynoc--;
			}
		}
	}

	//desallocations
	free(tabsynsup);


	//creation de la matrice des syno source x cliques cible = TFE*TEE'
    T_sel = (int **)calloc(nsyns, sizeof(int *));
	for (i=0; i<nsyns; i++)
	{ T_sel[i] = (int *)calloc(nclioc, sizeof(int)); }

	for (i=0; i<nsyns; i++)
	{
		for (j=0; j<nclioc; j++)
		{
			for (k=0; k<nsynoc; k++)
			{
				T_sel[i][j] += TFE[i][k]*TEE[j][k];
			}
		}
	}
	
	//selection des cliques cibles qui traduisent plus de nbtermesFE termes source
	nbclisup=0;
	tabclisup=(int *)calloc(nclioc, sizeof(int));
	for (i=0; i<nclioc; i++)
	{
		somme = 0;
		for (j=0; j<nsyns; j++)
		{
			if (T_sel[j][i]!=0)
			{ somme ++; }
		}
		if (somme < nbtermesFE)
		{
			//marquage de la clique a supprimer
			tabclisup[i]=1;
			nbclisup++;
		}
	}

	//suppression dans TEE
	for (i=0; i<nclioc; i++)
	{
		if (tabclisup[i]==1)
		{
			for (j=i; j<nclioc-1; j++)
			{
				TEE[j]=TEE[j+1];
				tabclisup[j]=tabclisup[j+1];
			}
			i--;
			nclioc--;
		}
	}

	//desallocation
	free(tabclisup);

	//suppression des termes cible qui n'appartiennent plus a aucune clique
	nbsynsup = 0;
	tabsynsup=(int *)calloc(nsynoc, sizeof(int));
	for (i=0; i<nsynoc; i++)
	{
		somme = 0;
		for (j=0; j<nclioc; j++)
		{ somme += TEE[j][i]; }
		if (somme==0)
		{
			nbsynsup++;
			tabsynsup[i] = 1;
		}
	}
	if (nbsynsup>0)
	{
		for (j=0; j<nsynoc; j++)
		{
			if (tabsynsup[j]==1)
			{
				//suppression dans TEE
				for (i=0; i<nclioc; i++)
				{
					for (k=j; k<nsynoc-1; k++)
					{ TEE[i][k]=TEE[i][k+1]; }
				}
				//suppression dans TFE
				for (i=0; i<nsyns; i++)
				{
					for (k=j; k<nsynoc-1; k++)
					{ TFE[i][k]=TFE[i][k+1]; }
				}
				//suppression dans le vecteur des synonymes
				for (k=j; k<nsynoc-1; k++)
				{
					strcpy(synoc[k],synoc[k+1]);
					tabsynsup[k]=tabsynsup[k+1];
				}
				j--;
				nsynoc--;
			}
		}
	}

	//desallocations
	free(tabsynsup);

	//selection des cliques cibles vides
	nbclisup=0;
	tabclisup=(int *)calloc(nclioc, sizeof(int));
	for (i=0; i<nclioc; i++)
	{
		somme = 0;
		for (j=0; j<nsynoc; j++)
		{
			somme += TEE[i][j];
		}
		if (somme == 0)
		{
			//marquage de la clique a supprimer
			tabclisup[i]=1;
			nbclisup++;
		}
	}

	//suppression dans TEE
	for (i=0; i<nclioc; i++)
	{
		if (tabclisup[i]==1)
		{
			for (j=i; j<nclioc-1; j++)
			{
				TEE[j]=TEE[j+1];
				tabclisup[j]=tabclisup[j+1];
			}
			i--;
			nclioc--;
		}
	}

	//desallocation
	free(tabclisup);

	//suppression des termes cible qui ne traduisent plus de terme source
	nbsynsup = 0;
	tabsynsup=(int *)calloc(nsynoc, sizeof(int));
	for (i=0; i<nsynoc; i++)
	{
		somme = 0;
		for (j=0; j<nsyns; j++)
		{ somme += TFE[j][i]; }
		if (somme==0)
		{
			nbsynsup++;
			tabsynsup[i] = 1;
		}
	}
	if (nbsynsup>0)
	{
		for (j=0; j<nsynoc; j++)
		{
			if (tabsynsup[j]==1)
			{
				//suppression dans TEE
				for (i=0; i<nclioc; i++)
				{
					for (k=j; k<nsynoc-1; k++)
					{ TEE[i][k]=TEE[i][k+1]; }
				}
				//suppression dans TFE
				for (i=0; i<nsyns; i++)
				{
					for (k=j; k<nsynoc-1; k++)
					{ TFE[i][k]=TFE[i][k+1]; }
				}
				//suppression dans le vecteur des synonymes
				for (k=j; k<nsynoc-1; k++)
				{
					strcpy(synoc[k],synoc[k+1]);
					tabsynsup[k]=tabsynsup[k+1];
				}
				j--;
				nsynoc--;
			}
		}
	}

	//desallocations
	free(tabsynsup);

	
	//test que tous les termes du langage source
	//ont une traduction
	nbsynsup = 0;
	tabsynsup=(int *)calloc(nsyns, sizeof(int));
	for (i=0; i<nsyns; i++)
	{
		somme = 0;
		for (j=0; j<nsynoc; j++)
		{
			somme+=TFE[i][j];
		}
		if (somme == 0)
		{
			nbsynsup++;
			tabsynsup[i] = 1;
		}
	}


//ecriture fichier de traduction en texte
#if 0
	//ecriture du nouveau fichier de traduction
	fo_trad = fopen(tradname, "wb");
	for (i=0; i<nsyns; i++)
	{
        fprintf(fo_trad, "%s\t:\t", syns[i]);
		for (j=0; j<nsynoc; j++)
		{
		if (TFE[i][j]==1)
			{ fprintf(fo_trad,"%s\t",synoc[j]); }
		}
        fprintf(fo_trad,"\n");
	}
	fclose(fo_trad);
#endif

  //ecriture fichier de traduction sous forme d'indice
	//ecriture du nouveau fichier de traduction sans les 
	//termes du langage source n'ayant pas de traduction
	fo_trad = fopen(tradname, "wb");
	for (i=0; i<nsyns; i++)
	{
		if (tabsynsup[i] == 0)
		{
			for (j=0; j<nsynoc; j++)
			{
			if (TFE[i][j]==1)
				{
				fprintf(fo_trad,"%d,",j+1);
				}
			}
			fprintf(fo_trad,"\n");
    }
	}
	fclose(fo_trad);


  if (nbsynsup > 0)
	{
		//tous les termes du langage source n'ont pas une traduction
		//=>supprimer ces termes et les enlever des cliques
		//lecture fichier cliques original langage cible
		fo_clis = fopen(clisname, "rb");
		if (fo_clis == NULL)
			{ return(-4); }
		nclis = 0;
		tailleCliqueMax=0;
		tmptailleclique=0;
		do
		{
			c=fgetc(fo_clis);
			if (c=='\n')
			{
				nclis++;
				if (tmptailleclique>tailleCliqueMax)
					tailleCliqueMax=tmptailleclique;
				tmptailleclique=0;
			}
			if (c==',')
				tmptailleclique++;
		}while (c!=(char)-1);

		clis=(cClique*)malloc(sizeof(cClique)*nclis);
		fseek(fo_clis,0,0);
		for (i=0;i<nclis;i++)
		{
			pclis=&clis[i];
			pclis->element=(int*)malloc(sizeof(int)*tailleCliqueMax);
			pclis->nelements=0;
			num=0;
			do
			{
				c=fgetc(fo_clis);
				if (c==',')
				{
					pclis->element[pclis->nelements]=num-1;
					num=0;
					pclis->nelements++;
				}
				if ((c>='0') && (c<='9'))
				{
					num=num*10+c-'0';
				}
			}while (c!='\n');
		}

		fclose(fo_clis);

		//allocation matrice cliques source x syno source
		TFF = (int **)calloc(nclis, sizeof(int *));
		for (i=0; i<nclis; i++)
		{ TFF[i] = (int *)calloc(nsyns, sizeof(int)); }

		//initialisation matrice TEE
		for (i=0; i<nclis; i++)
		{
			for (j=0; j<clis[i].nelements; j++)
			{ TFF[i][clis[i].element[j]] = 1; }
		}

		//suppression des termes du langage source n'ayant pas de traduction
		for (i=0; i<nsyns; i++)
		{
			if (tabsynsup[i] == 1)
			{
				//suppression dans TFF
				for (j=0; j<nclis; j++)
				{
					for (k=i; k<nsyns-1; k++)
					{
						TFF[j][k]=TFF[j][k+1];
					}
				}


				//suppression dans syns
				for (j=i; j<nsyns-1; j++)
				{
					strcpy(syns[j], syns[j+1]);
					tabsynsup[j]=tabsynsup[j+1];
				}
				nsyns--;
				i--;
			}
		}

		//reecriture du fichier de synonymes purge
		fo_syns = fopen(synsname, "wb");
		for (i=0; i<nsyns; i++)
		{
			fprintf(fo_syns,syns[i]);
			fprintf(fo_syns,"\n");
		}
		fclose(fo_syns);

		//reecriture du fichier de cliques purge
		fo_clis = fopen(clisname, "wb");
		for (i=0; i<nclis; i++)
		{
			for (j=0; j<nsyns; j++)
			{
			if (TFF[i][j]==1)
				{ fprintf(fo_clis,"%d,",j+1);}
			}
			fprintf(fo_clis,"\n");
		}
		fclose(fo_clis);

	}

	//desallocations
	free(tabsynsup);

	//ecriture du nouveau fichier de synonymes cible
	fo_sync = fopen(syncname, "wb");
	for (i=0; i<nsynoc; i++)
	{
        fprintf(fo_sync,synoc[i]);
        fprintf(fo_sync,"\n");
	}
	fclose(fo_sync);

	//ecriture du nouveau fichier de cliques cible
	fo_clic = fopen(clicname, "wb");
	for (i=0; i<nclioc; i++)
	{
    for (j=0; j<nsynoc; j++)
		{
		if (TEE[i][j]==1)
			{ fprintf(fo_clic,"%d,",j+1);}
		}
        fprintf(fo_clic,"\n");
	}
	fclose(fo_clic);

	//debug
	fo_clic = fopen("clique.debug", "wb");
	for (i=0; i<nclioc; i++)
	{
        for (j=0; j<nsynoc; j++)
		{
		if (TEE[i][j]==1)
			{ fprintf(fo_clic,"%s,",synoc[j]);}
		}
        fprintf(fo_clic,"\n");
	}
	fclose(fo_clic);





	return 0;
}
