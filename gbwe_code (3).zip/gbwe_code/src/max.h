/*  max.h  */
#ifndef MAX_H
#define MAX_H

double max(double a, double b);

#endif /* MAX_H */
