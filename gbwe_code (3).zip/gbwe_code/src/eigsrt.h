/* eigsrt.h */

#ifndef EIGSRT_H
#define EIGSRT_H

void eigsrt(double d[], double **v, int n);

#endif /* EIGSRT_H */
