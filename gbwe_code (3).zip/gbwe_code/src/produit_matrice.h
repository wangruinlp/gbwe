/* produit_matrice.h */

#ifndef PRODUIT_MATRICE_H
#define PRODUIT_MATRICE_H

void produit_matrice(double **mv,double **m01,int ligne,int colonne);

#endif  /* PRODUIT_MATRICE_H */
