int intint(int *v, int nv, int *u, int nu);
