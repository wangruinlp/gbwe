/* classe.h */

#ifndef CLASSE_H
#define CLASSE_H

#define CLASSE(c_ident) typedef struct c_ident *c_ident

#endif  /* CLASSE_H */
