int countTokens( const char *s, const char v)
{
  register int n = 1;

  while (*s)
  {
	if (*s++ == v)
		n++;
  }
  //if(*(--s)==v)
//	  n--;
  return n;
}
