#define false 0
#define true 1
int
intint(int *v, int nv, int *u, int nu)
{
	int i,j,nEquals=0,init=0;
	for(j=0;j<nu;j++)
	{
		for(i=init;i<nv;i++)
		{
			if(u[j]==v[i])
			{
				nEquals++;
				init=i;
				break;
			}
		}
	}
	if(nEquals==nu)
		return true;
	else
		return false;
}
