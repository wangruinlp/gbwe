void
toHtml(char *t, const char *s, const char v)
{
	register int c;
	while((c=*s++)!=v && c)
	{
          	if (c==' ')
			*t='+';
          	else if (c>'z' || c<'a') 
		{
			if (c<0) c+=256;  // ca saoule...
			sprintf(t,"%%%2X",c);
			t+=2;
          	}
          	else
			*t=c;
		t++;
	}
	*t='\0';
}
