/**
 * ncopy(to,"stri[ng[2,3,4...", '[');
 * == copy(to,"string");
 *
 * CAUTION : this does not examine whether the length of "t" is too short or not. 
 * It might cause "Segmentation fault in case "s" does not have  "token".
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "debug.h"
void ncopy (char * t, const char *s, const char v)
{
	register const char *p=s;
	register char *q=t;
	register char *r;

	if((r=strrchr(p,v))==NULL)
	{
		strcpy(q,p);
		return;
	}
	//while( *p!=v && (*q++ = *p++))
	while(p<r)
	{
		*q++ = *p++;
	}
	*q = '\0';
	return;
}
