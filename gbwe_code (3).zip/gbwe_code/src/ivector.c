#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#define NR_END 1
//#define FREE_ARG char*

int *
ivector(int nl, int nh)
/* allocate an int vector with subscript range v[nl..nh] */
{
        int *v;

        v=(int *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(int)));
        if (!v){} //error("allocation failure in ivector()");
        return v-nl+NR_END;
}
