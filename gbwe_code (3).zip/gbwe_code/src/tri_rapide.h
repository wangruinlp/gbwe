#ifndef TRI_RAPIDE_H
#define TRI_RAPIDE_H

void tri_rapide(int Ax[],double Ae[], int p , int r);
int partionner(int Ax[],double Ae[], int p, int r);

#endif   /* TRI_RAPIDE_H */
