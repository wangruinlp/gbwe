FILE *dicofopen(const char *,const char *);
void dicofclose(FILE *);
