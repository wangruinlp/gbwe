/*      erreurs.c    du 26 juin 98     */

#include <stdlib.h>
#include "erreurs.h"

char *err_malloc = "erreur d'allocation m�moire";
char *err_calloc = "erreur d'allocation m�moire (calloc)";
char *err_realloc = "erreur d'extension m�moire";
