#define COLON_EN ":"
#define COLON_FR " :"
