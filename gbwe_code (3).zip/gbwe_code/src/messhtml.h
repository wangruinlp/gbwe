void write_html_retour_garde();
void write_html_nouvelle_req();
void write_html_erreur_interne(const char *);
void write_html_req_invalid();
void write_html_return_homepage();
void write_html_new_search();
void write_html_internal_error(const char*);
void write_html_invalid_req();

