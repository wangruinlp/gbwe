/* tqli.h */

#ifndef TQLI_H
#define TQLI_H

void tqli(double d[],double e[], int n, double **z);

#endif /* TQLI_H */
