/* minimum.c */

#include "minimum.h"

int minimum( int ligne, int colonne, int compo )
{
  int valeur;
  valeur = compo;
  if ( ligne < colonne )
    {
      if ( ligne < valeur )
	{
	  valeur = ligne;
	}
    }
  else
    {
      if ( colonne < valeur )
	{
	  valeur = colonne;
	}
    }
  return valeur;
}
