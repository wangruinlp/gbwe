void
getVedettesStr(char *t, const char *s, const char v)
{
	register char *q=t;
	while(*s)
	{
		if(*s==v)
		{
			*q++ = ' ';
			s++;
		}
		else
			*q++ = *s++;
	}
	*q=0;
}
			

