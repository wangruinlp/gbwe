//This is for final Contexonym graph construction.
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#define MaxSize 10000
#define MaxSym 30000

typedef char* lst;

typedef struct article_t
{
	char * entete;
	lst * synonymes;
	int nbsyn;
	article_t *succ;
}article_t;

int getString(FILE * f, char * d)
{
	char c = 0;
	do
	{
		c = fgetc(f);
		if ((c == '\n') || (c == ':'))
		{
			c = fgetc(f);
			if (c == '\t')
				c = fgetc(f);
		}

		if (d != NULL)
		{
			d[0] = c;
			d++;
		}
	} while ((c != '\t') && (!(c == EOF)));

	if (d != NULL)
	{
		if (c == EOF)
		{
			d[-1] = 0;
			d[0] = 0;
		}
		else
		{
			d[-1] = 0;
			if (d[-2] == '	')
				d[-2] = 0;
		}
	}
	return !(c == EOF);
}

bool eol(FILE *f)
{
	char c = fgetc(f);
	if ((c == 10) || (c == 13))
		return true;
	ungetc(c, f);
	return false;
}

void creation(article_t *T)
{
	T->entete = new char;
	T->synonymes = new lst[MaxSym];
	T->nbsyn = 0;
	T->succ = NULL;
}

void ajout(article_t * courant, article_t * premier)
{
	article_t * succs;
	if (courant == NULL)
	{
		premier->succ = new article_t;
		creation(premier->succ);
	}
	else
	{
		succs = courant;
		premier->succ = new article_t;
		creation(premier->succ);
		(premier->succ)->succ = succs;
	}
}

int main(int pargc, char ** argv)
{
	article_t * dico = new article_t;
	article_t * courant, *courants, *premier, *succs, *courantp;
	FILE *fw;
	FILE *fs;
	long nSyn = 0;

	if (!(fw = fopen(argv[1], "r")))
	{
		printf("No input file");
	}
	if (!(fs = fopen(argv[2], "wb")))
	{
		printf("No output file");
	}

	int m, ll, l;
	char mot[MaxSize], mt[MaxSize];
	char c;
	creation(dico);
	strcpy(dico->entete, "		");

	while (getString(fw, mot))
	{
		courant = dico->succ;
		premier = dico;

		printf("%s 1", mot);
		while ((courant != NULL) && (strcmp(courant->entete, mot) < 0))
		{
			premier = courant;
			courant = courant->succ;
		}

		if ((courant == NULL) || (strcmp(courant->entete, mot) != 0))
		{
			ajout(courant, premier);
			courant = premier->succ;
			nSyn++;
			delete courant->entete;
			courant->entete = new char[strlen(mot) + 1];
			strcpy(courant->entete, mot);
		}

		mot[0] = '\0';
		c = fgetc(fw);
		c = fgetc(fw);
		while (!eol(fw) && (getString(fw, mot)))
		{
			courants = dico->succ;
			premier = dico;
			while ((courants != NULL) && (strcmp(courants->entete, mot) < 0))
			{
				premier = courants;
				courants = courants->succ;
			}
			if ((courants == NULL) || (strcmp(courants->entete, mot) != 0))
			{
				ajout(courants, premier);
				courants = premier->succ;

				nSyn++;
				delete courants->entete;
				courants->entete = new char[strlen(mot) + 1];
				strcpy(courants->entete, mot);
			}

			m = 0;
			while ((m < courants->nbsyn) && (strcmp(courants->synonymes[m], courant->entete) < 0))
				m++;
			if ((courants->nbsyn == 0) || (m == courants->nbsyn) || (strcmp(courants->synonymes[m], courant->entete) != 0))
			{
				courants->synonymes[courants->nbsyn] = new char;
				for (ll = courants->nbsyn; ll > m; ll--)
				{
					delete courants->synonymes[ll];
					courants->synonymes[ll] = new char[strlen(courants->synonymes[ll - 1]) + 1];
					strcpy(courants->synonymes[ll], courants->synonymes[ll - 1]);
				}
				delete courants->synonymes[m];
				courants->synonymes[m] = new char[strlen(courant->entete) + 1];
				strcpy(courants->synonymes[m], courant->entete);
				courants->nbsyn++;
			}

			m = 0;

			while ((m < courant->nbsyn) && (strcmp(courant->synonymes[m], mot) < 0))
				m++;

			if ((m == courant->nbsyn) || (strcmp(courant->synonymes[m], mot) != 0))
			{
				l = courant->nbsyn;
				(courant->synonymes[l]) = new char;

				if (m != courant->nbsyn)
				for (ll = courant->nbsyn; ll > m; ll--)
				{
					delete courant->synonymes[ll];
					courant->synonymes[ll] = new char[strlen(courant->synonymes[ll - 1]) + 1];
					strcpy(courant->synonymes[ll], courant->synonymes[ll - 1]);
				}
				delete courant->synonymes[m];
				courant->synonymes[m] = new char[strlen(mot) + 1];
				strcpy(courant->synonymes[m], mot);
				courant->nbsyn++;
			}
			mot[0] = '\0';
		}
		printf("%d \n", nSyn);
	}

	courantp = dico->succ;

	while (courantp != NULL)
	{
		fprintf(fs, "%s	:	", courantp->entete);
		for (int k = 0; k < courantp->nbsyn; k++)
			fprintf(fs, "%s	", courantp->synonymes[k]);
		courantp = courantp->succ;
		fprintf(fs, "\n");
	}
	fclose(fs);
	fclose(fw);
	return 0;
}
