/* marquage.h */

#ifndef MARQUAGE_H
#define MARQUAGE_H

int marquage( int sommet, int niveau,int taille, int GAMA[],pilegen pile_e1, double **NTN, int compteur );

#endif /* MARQUAGE_H */
