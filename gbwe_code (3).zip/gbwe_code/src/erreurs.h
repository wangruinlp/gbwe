/*      erreurs.h       du 26 juin 98  */

#ifndef ERREURS_H
#define ERREURS_H

extern char *err_malloc;
extern char *err_calloc;
extern char *err_realloc;

#endif  /*    ERREURS_H   */
