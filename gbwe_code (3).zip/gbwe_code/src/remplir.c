/*  remplir.c */

#include "remplir.h"

/******************************************************************/
/*         fonctions d'initialisation de vecteurs                 */
/******************************************************************/


void rempli(double *vect,int taille,double valeur)
{
  int i;
  for ( i = 0; i < taille ; i++ )
    {
      vect[i] = valeur;
    }
}

void rempli_i(int *vect,int taille,int valeur)
{
  int i;
  for ( i = 0; i < taille ; i++ )
    {
      vect[i] = valeur;
    }
}
