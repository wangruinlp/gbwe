/*      produit_croise.c   */
#include<stdio.h>
#include"produit_croise.h"
#define PRECISION 0.00001

int produit_croise(double x0,double y0,double x1,double y1,double x2,double y2)
{
  double valeur;
  valeur = (x1-x0)*(y2-y0)-(x2-x0)*(y1-y0);
  if ( valeur > PRECISION )
    return 1;
  else
    if (valeur < -PRECISION )
      return -1;
    else
      return 0;
}
