int 
toSyns(char **t, const char **s, int n)
{
	int i,j=0;
	register char *p;
	register char *q=t[0];
	for(i=0;i<n;i++)
	{
		p=s[i];
		while(*p!='\t' && *p)
			*q++ = *p++;
		*q='\0';
		p+=3;
		j++;
		q=t[j];
		while(*p)
		{
			while(*p!='\t' && *p)
				*q++ = *p++;
			*q='\0';
			if(strlen(t[j])>0)
				j++;
			q=t[j];
			if(*p==0)
				break;
			
			p++;
		}
	}
	return j;
}
