#include <string.h>
int 
toTokens( char **t, const char *s, const char v, int nTokens)
{ 
	register int i = 0; 
	register char *q;
	q=t[0];
//	nTokens--;
	while (*s)
	{
	      if(*s==v)
	      {
		      *q='\0';
		      q= t[++i];
		      s++;
		      if(i>nTokens)
		      {
			      if(*(++s)==0)
				      return i;
			      else
				      return ++i;
		      }

	      }
	      else 
		      *q++ = *s++;
	}
	*q='\0';
	if(*(--s)!=v && strlen(t[i])>0)
		i++;
	return i;
}
