/* pilegen.h */

#ifndef PILEGEN_H
#define PILEGEN_H

#include "classe.h"

CLASSE(pilegen);

extern pilegen pilegen_faire(void);
extern void pilegen_defaire(pilegen recv);
extern void pilegen_empiler(pilegen recv, void * element);
extern void *pilegen_depiler(pilegen recv);
extern int pilegen_vide(pilegen recv);
extern void *pilegen_sommet(pilegen recv);
extern void pilegen_mode_bavard(pilegen recv, int mode);

#endif /* PILEGEN_H */
