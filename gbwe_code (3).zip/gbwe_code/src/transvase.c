/*   transvase.c  */
#include "pilegen.h"
#include "transvase.h"

int transvase(pilegen pile_e1,pilegen pile_e2)
{
  if (pilegen_vide(pile_e2))
    return 1;
  do
    {
      pilegen_empiler(pile_e1,pilegen_depiler(pile_e2));
    } while ( !pilegen_vide(pile_e2));
  return 1;
}
