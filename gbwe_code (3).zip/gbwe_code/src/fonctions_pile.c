/* fonctions_pile.c */

#include "fonctions_pile.h"

/******************************************************************/
/*         fonctions de pile                                      */
/******************************************************************/
void creer_pile(int PILE[],int taille)
{
  PILE[0] = -1;
}


int depile(int PILE[],int taille)
{
  int i;
  int valeur;
  if ( PILE[0] == -1 )
    return -1;
  for( i = 0 ; i < taille ; i ++)
    {
      if ( PILE[i] == -1 )
        break;
    }
  if ( i == taille )
    {
      if ( PILE[taille-1] == -1 )
        {
          valeur = PILE[taille-2];
          PILE[taille-2] = -1;
        }
      else
        {
          valeur = PILE[taille-1];
          PILE[taille-1] = -1;
        }
    }
  else
    {
      valeur = PILE[i-1];
      PILE[i-1] = -1;
    }
  return valeur;
}

int pile_vide(int PILE[])
{
  if ( PILE[0] == -1 )
    return 1;
  else
    return 0;
}

int empile( int sommet, int PILE[], int taille )
{
  int i;
  for( i = 0 ; i < taille ; i ++ )
    {
      if ( PILE[i] == -1 )
        {
          PILE[i] = sommet;
	  PILE[i+1] = -1;
          break;
        }
    }
  if ( i == taille )
    {
      return -1; /* pile pleine */
    }
  else
    {
      return 1;
    }
}

int sommet(int PILE[],int taille)
{
  int i;
  if ( PILE[0] == -1 )
    return -1;
  for( i = 1 ; i < taille ; i ++ )
    {
      if ( PILE[i] == -1 )
	return PILE[i-1];
    }
  if ( i == taille )
    return PILE[taille-1];
  return 0;
}
