////This is for the index of the final Contexonym graph.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
	char name[250];
	int dicopos;

	int ifg,ifd;
	int posfg,posfd;

	int limitmin //limite minimale
		, limitmax; //limite maximale
}mot;

int linesize(mot* m)
{
	return strlen(m->name)+3*11+1;
};

//formazt 

int main(int argc, char **argv)
{
	//FILE* f_dic=fopen("vs_dicos.com_en","rb");
	//FILE* f_ind=fopen("index.arb.com_en","wb");
	FILE* f_dic=fopen(argv[1],"rb");
	FILE* f_ind=fopen(argv[2],"wb");
	//FILE* f_dic=fopen("vs_dicosb320px","rb");
	//FILE* f_ind=fopen("indexb320px.arb","wb");


	int i,j; //variables de boucle
	char* pd;

	int ifg,ifd,ip; //variables temporaires
	mot* pmot;
	char c;
	int indpos;
	int* tmppile;


	int nmots=0;
	mot* tabmot;

	int ipile_parent;
	int ipile_enfant;
	int* pile_parent;
	int* pile_enfant;


	while ((c=fgetc(f_dic))!=-1) { if (c=='\n') nmots++; }

	//printf("%d\n",nmots);

	tabmot=(mot*)malloc(nmots*sizeof(mot));

	fseek(f_dic,0,0);
	for (i=0;i<nmots;i++)
	{
		tabmot[i].dicopos=ftell(f_dic);
		pd=tabmot[i].name;
		while ((c=fgetc(f_dic))!='\t') { pd[0]=c; pd++; }
		while (fgetc(f_dic)!='\n') {}
		pd[0]=0;
	}

	//initialisation des piles
	pile_parent=(int*)malloc(nmots*sizeof(int));
	pile_enfant=(int*)malloc(nmots*sizeof(int));
	ipile_enfant=0;
	i=nmots/2;
	pile_parent[0]=i;
	ipile_parent=1;
	tabmot[i].limitmin=0;
	tabmot[i].limitmax=nmots-1;
	indpos=linesize(&tabmot[i]); //indpos=prediction de la position du prochain fils

	while(ipile_parent>0)
	{
/*
		for (i=0;i<ipile_parent;i++)
		{
			printf("%d ",pile_parent[i]);
		}
		printf("\n\n\n");
*/

		//generation de la pile enfant
		for (i=0;i<ipile_parent;i++)
		{
			ip=pile_parent[i];
			pmot=&tabmot[ip];
			ifg=pmot->limitmin+(ip-pmot->limitmin)/2;
			ifd=ip+(pmot->limitmax-ip+1)/2;
			if (ifg==ip) ifg=-1;
			if (ifd==ip) ifd=-1;
			pmot->ifg=ifg;
			pmot->ifd=ifd;
			if (ifg>=0) 
			{
				pile_enfant[ipile_enfant]=ifg; 
				ipile_enfant++; 
				tabmot[ifg].limitmin=pmot->limitmin;
				tabmot[ifg].limitmax=ip-1;
				pmot->posfg=indpos;
				indpos+=linesize(&tabmot[ifg]);
			}
			else
			{
				pmot->posfg=0;
			}
			if (ifd>=0) 
			{ 
				pile_enfant[ipile_enfant]=ifd; 
				ipile_enfant++; 
				tabmot[ifd].limitmin=ip+1;
				tabmot[ifd].limitmax=pmot->limitmax;
				pmot->posfd=indpos;
				indpos+=linesize(&tabmot[ifd]);
			}
			else
			{
				pmot->posfd=0;
			}
			fprintf(f_ind,"%s:% 10d:% 10d:% 10d\n",pmot->name,pmot->dicopos,pmot->posfg,pmot->posfd);
		}

		//passage � la nouvelle generation
		tmppile=pile_parent;
		pile_parent=pile_enfant;
		pile_enfant=tmppile;
		ipile_parent=ipile_enfant;
		ipile_enfant=0;

	}
/*
	for (i=0;i<ipile_parent;i++)
	{
		printf("%d ",pile_parent[i]);
	}
	printf("\n\n\n");
*/

	fclose(f_ind);
	return 0;
};
