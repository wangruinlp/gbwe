#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "utils.h"
#include "words.h"

/** 
 * sorting and counting of words that already have numbers and position
 */
int fintsort_child(FILE* fo, int * s, int n, int write_head, int sort_freq, int sort_words, const char token)
{
	int  *id;
	int init=0;
	int  *i_freq;
	int *idx;
	int *freq;
	int **p;
	int i, j, k, l;
	int newword;
	int r,r2;
	int in=0;
	int nwords;
	char w[256];
	if(n==1)
	{
		fprintf(fo,"%s\t\n",s[init]);
		return 1;
	}


  	//words=cmatrix(init,n-1,0,maxwordlen);
	id = ivector(init, n-1);
	if(sort_words)
		index_int(init, n-1, s, id);
	else
		for(i=init;i<n;i++)
			id[i]=i;
	i=0;
       	//for(i=nwords;i>=init;i--)
       	for(i=init;i<n;i++)
		//fprintf(fo,"%s\t",s[id[i]]);
		fprintf(fo,"%d%c",s[id[i]],token);
	fprintf(fo,"\n");
	free_ivector(id,init,n-1);
	return k+1;
}
