/* taille_tampon.h */

#define TAILLE_TAMPON 1024
