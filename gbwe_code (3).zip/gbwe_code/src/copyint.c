void 
copyint(int* to, int* from, int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		to[i]=from[i];
	}
}
	
