#define NR_END 1
#define FREE_ARG char*
#define NULL 0

void free_cvector( char *v, int nl, int nh)
/* free a char vector allocated with cvector() */
{
	if(v==NULL)
		return;
        free((FREE_ARG) (v+nl-NR_END));
}
