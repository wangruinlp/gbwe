#ifndef TRANSVASE_H
#define TRANSVASE_H

int transvase(pilegen pile_e1,pilegen pile_e2);

#endif /*  TRANSVASE_H  */
