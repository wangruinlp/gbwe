//#define MaxLine 10000
//#define	 MAX_word_len 255
//#define	 MAX_line_len 5000

int getSynLine1(const char* word,char* line,const char *base); //copie dans la chaine 'line', la ligne du dictionnaire associ�e au mot 'word'
//void getSynLine(char* word,char* line,char *base); //copie dans la chaine 'line', la ligne du dictionnaire associ�e au mot 'word'
