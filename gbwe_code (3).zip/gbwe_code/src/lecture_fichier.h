/* lecture_fichier.h */

#ifndef LECTURE_FICHIER_H
#define LECTURE_FICHIER_H

struct coord {
  int i;
  int j;
};
typedef struct coord coord;

void lecture_fichier_num(vecteur v,FILE * flot, char * sep, coord *coord);

#endif  /* LECTURE_FICHIER_H */

