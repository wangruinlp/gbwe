#include <stdio.h>
#include <string.h>

/* Reads characters from STREAM into S, until either a newline character
   is read, N - 1 characters have been read, or EOF is seen. Finishes by
   appending a null character and returning S.  If EOF is seen before any 
   characters have been written to S, the function returns NULL without 
   appending the null character.
   If there is a file error, always return NULL. 
   */
int fgetline ( char *s, int n, FILE *stream)
{
	register char *p=s;
	if(fgets(p, n, stream) == NULL)
		return -1;
	else
	{
		if(strlen(s)==n-1)
			return -2;
		p+=(strlen(s)-1);
		p--;
		while(*p == 13)
			p--;
		p++;
		*p='\0';
		return p-s;
	}
}
