/* ----------------------------------------------------------- */
/*    lecture des fichiers .cli et .doc                        */
/*    mise en forme de matrice                                 */
/*    produit de la matrice avec sa transposee                 */
/*    calcul des marges pour recherche fermeture transitive    */
/*    affichage du temps de calcul                             */
/* ----------------------------------------------------------- */
/* ferm_tran.c   par Francis BOUDIN pour l'isc      le 8/10/99 */

#include<sys/types.h>
#include<sys/time.h>
#include<time.h>
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<unistd.h>
#include<string.h>
//#include<time.h>

#include"taille_tampon.h"
#include"exit_if.h"
#include"erreurs.h"
#include"nrutils.h" 
#include"remplir.h"
#include"vecteur.h"
#include"pilegen.h"
#include "affiche.h"
#include "matrice_khi2.h"
#include "produit_matrice.h"
#include"acces_fichier.h"
#include"lecture_fichier.h"
#include"cree_matrice_01.h"
#include "marquage.h"

//#define CLEAR() printf("\033[2J")
  
/* somme marginale en colonne */

/******************************************************************/
/*         fonction principale                                    */
/******************************************************************/
 
int main ( int argc, char *argv[] )
{
//  double tdiff;
//  long tdiffm;
  //struct timeval *temps1;
  //struct timeval *temps2;
   //struct timezone *tps1;
//  struct timespec *temps1;
 // struct timespec *temps2;

  FILE *flot;
  int i,j;
  int indice_du_Max;
  int sommet;
  int compteur;
  double Max;
  int entier;
  double **t1;
  double **NTN;
  double *D2;
  int *GAMA;

  FILE *fp;
  int iv;
  char* stri;
  char c;

  
  coord coordi;
  pilegen pile_e1;
  vecteur v;

  pile_e1 = pilegen_faire();
  pilegen_mode_bavard(pile_e1,1);
  v = vecteur_faire();
  //temps1 = malloc(TAILLE_TAMPON);
 // temps2 = malloc(TAILLE_TAMPON);

  if ( argc != 2 )
    {
      fprintf(stderr, "Usage : %s <<nom de la vedette>>\n",argv[0]);
      return EXIT_FAILURE;
    }

  //gettimeofday(temps1,tps1);
//  clock_gettime(CLOCK_REALTIME,temps1);

/*
  sprintf(fpname,"%s.iv",argv[1]);
  fp=fopen(fpname,"r");
  */
  fp= malloc(sizeof(FILE *));
  fp= ouvre_fichier(argv[1],".iv","r");
  stri=malloc(256*sizeof(char));
  i=0;
  while((c=fgetc(fp))!='\n' && c!=EOF)
      stri[i++]=c;
  stri[i]=0;
  i=0;
  iv=atoi(stri);
  fclose(fp);



  flot = malloc(sizeof(FILE *));
  flot = ouvre_fichier(argv[1],".clio","r");
  lecture_fichier_num(v,flot,",",&coordi); 
  fclose(flot);
/*    printf(" resultat : cliques %d, synonymes %d \n", coordi.i, coordi.j); */

  t1 = dmatrix(1,coordi.i,1,coordi.j);

  cree_matrice(v,t1,coordi.i,coordi.j);  

/*    affiche_matrice(t1,coordi.i,coordi.j); */

  NTN = dmatrix(1,coordi.j,1,coordi.j);

  D2 = malloc((coordi.j+1)*sizeof(double));
  rempli(D2,coordi.j+1,0);

  Max = 0;
  indice_du_Max = 0;


  for ( i = 1 ; i <= coordi.i ; i ++ )
    {
      for( j = 1 ; j <= coordi.j ; j ++ )
	{
	  D2[j] = D2[j] + t1[i][j];
	  if ( Max < D2[j] )
	    {
	      Max = D2[j];
	      indice_du_Max = j;
	    }
	}
    }
/*    affiche_marge(D2,coordi.j);  */
/*    printf("indice_du_Max : %i\n",indice_du_Max ); */

  /* *****************************************************
     mise a zero de la colonne vedette        
     (elle correspond a la somme colonne maximale)
     ****************************************************** */
  if ( Max == coordi.i )
  {
    for( i = 1 ; i <= coordi.i ; i ++ )
      {
        t1[i][indice_du_Max] = 0;
      }
  }
 	    
  /************************************/
  /* calcul de la matrice tN x N      */
  /************************************/

  produit_matrice(NTN,t1,coordi.i,coordi.j);
/*    affiche_matrice(NTN,coordi.j,coordi.j); */
/*    getchar(); */

  /* *****************************************************
     algorithme de recherche de fermeture transitive    
     par un parcours en profondeur                 
     sur la matrice symetrique prise sur la synonymie  
     ***************************************************** */

  flot = ouvre_fichier(argv[1],".fer", "w");
  
  if (coordi.j==1)
  {
	fprintf(flot,"0 \n");
	fclose(flot);
	return 0;
  }

  GAMA = malloc((coordi.j+1)*sizeof(int));
  rempli_i(GAMA,coordi.j+1,-1);
  compteur = coordi.j;
/*    printf(" fermeture transitive \n"); */
  for ( sommet = 1; sommet <= coordi.j ; sommet++ )
    {
      if (GAMA[sommet] != -1) continue;
      if ( indice_du_Max == sommet )
	{
	  GAMA[sommet] = sommet;
	  compteur--;
	  continue;
	}
      GAMA[sommet] = sommet;
      compteur = marquage(sommet,sommet,coordi.j,GAMA,pile_e1,NTN,compteur-1);
      while( (compteur > 0) && ( !pilegen_vide(pile_e1)) )
	{
	  entier = *(int *) pilegen_depiler(pile_e1);
	  compteur = marquage(entier,sommet,coordi.j,GAMA,pile_e1,NTN,compteur);
	}
      for( i = 1 ; i <= coordi.j ; i++ )
	{
		if ( GAMA[i] == sommet)
	    	{
			if(i==iv+1)
	      			fprintf(flot,"0 ");
			else 
	      			fprintf(flot,"%d ", i-1);
	    	}
	}
      fprintf(flot,"\n");
/*        affiche_fermeture(sommet,GAMA,coordi.j); */
      fflush(NULL);
      while(  !pilegen_vide(pile_e1) )
	{
	  pilegen_depiler(pile_e1);
	}
    }
  fclose(flot);
  /*
  //gettimeofday(temps2,tps1);
  clock_gettime(CLOCK_REALTIME,temps2);
  tdiff = difftime(temps2->tv_sec,temps1->tv_sec);
  //tdiffm = temps2->tv_usec-temps1->tv_usec;
  tdiffm = temps2->tv_sec-temps1->tv_sec;
  //    printf("temps ecoule : %.0f seconde(s) %ld microseconde(s) \n",tdiff,tdiffm); 
  tdiff = tdiff*1000000 + tdiffm;
  */
/*    printf("temps ecoule : %.0f microsecondes \n",tdiff); */

  return 0;
}







