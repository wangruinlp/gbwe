/* matrice_khi2.c */

#include "matrice_khi2.h"
#include "nrutils.h"
#include <math.h>

/******************************************************************/
/* fonction de produit de transposee de matrice par la matrice    */
/******************************************************************/

void matrice_khi2(double **m01,double **m02,double D1[],double D2[],int ligne,int colonne)
{
  int i;
  int j;


  for ( i = 1 ; i <= ligne ; i ++ )
    {
      for ( j = 1 ; j <= colonne ; j ++ )
	{ if (fabs(D2[j]*D1[i])>0.0001 && fabs(m02[i][j])>0.0001 )
	  {m01[i][j] = m02[i][j]*sqrt(fabs(D2[j]*D1[i]));
	//printf("le carre %f %f\n",sqrt(fabs(D2[j]*D1[i])),m02[i][j]);
}
	else
	{m01[i][j]=0;
	//printf("le carre pb %f %f\n",sqrt(fabs(D2[j]*D1[i])),m02[i][j]);
}

	}
    }  
}






