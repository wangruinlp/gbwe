/*  min.c  */
#include"min.h"

double min(double a, double b)
{
  if ( a < b ) 
    return a;
  else
    return b;
}

int min_i(int a, int b)
{
  if ( a < b ) 
    return a;
  else
    return b;
}

