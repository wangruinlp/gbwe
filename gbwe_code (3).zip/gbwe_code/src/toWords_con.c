#include <string.h>
int 
toWords_con( char **t, const char *s, const char v, int dico)
{ 
	register int i = 0; 
	register char *q;
	q=t[0];
	if(dico)
	{
		while (*s!=v)
			*q++ = *s++;
		*q='\0';
		q= t[++i];
		s+=3;
	}
	while (*s)
	{
	      if(*s==v)// || *s==13 || *s=='\t' || *s=='\n')
	      {
		      *q='\0';
		      if(strlen(t[i])>0)
			      i++;
		      q= t[i];
		      s++;
	      }
	      else 
		      *q++ = *s++;
	}
	*q='\0';
	if(*(--s)!=v && strlen(t[i])>0)
		i++;
	return i;
	/*
	if(*(s-1) != v)
	{
		*q='\0';
		if(i>0)
			i++;
	}
	return i;
	*/
}
