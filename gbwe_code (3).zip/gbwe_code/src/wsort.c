/** 
 * sorting words 
 */

#define isEqual(a, b) (strcmp ((a), (b)) == 0)
int wsort(char ** t, const char ** s, int n, int maxwordlen)
{
	int  *id;
	int nw=0;
	int i;
	id = ivector(0, n-1);
	indexx(0, n-1, s, id, maxwordlen);
	//strcpy(t[nw++],s[0]);
	strcpy(t[nw],s[id[0]]);
	nw++;
	for (i=1; i<n; i++) 
	{
		if(isEqual(s[id[i-1]],s[id[i]]))
			continue;
		strcpy(t[nw],s[id[i]]);
		nw++;
	}
	free_ivector(id, 0, n-1);
	return nw;
}
