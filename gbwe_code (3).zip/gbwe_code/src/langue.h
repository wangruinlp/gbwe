#define LFRANCAIS 1
#define LANGLAIS 2
#define LFRENCH 3
#define LENGLISH 4
