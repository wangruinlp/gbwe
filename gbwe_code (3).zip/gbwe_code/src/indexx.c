#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#define SWAP(a,b) itemp=(a);(a)=(b);(b)=itemp;
#define NSTACK 50
#define M 7
void indexx(const int init, const int n, const char **arr, int index[], int maxwordlen)
{
	int  i, idt, ir = n, itemp, j, k, l = init;
	int  jstack = 0, *istack;
	char str[maxwordlen];
	register char *p;
	register char **q;
	register int *id;
	p=str;
	q=arr;
	id=index;
	
	//istack = ivector(init, NSTACK-(1-init));
	istack = ivector(1, NSTACK);
	for (j = init; j <= n; j++)
		id[j] = j;
	for (;;) 
	{
		if (ir-l < M) 
		{
			for (j = l+1; j <= ir; j++) 
			{
				idt = id[j];
				p = q[idt];
				//strcpy(c, q[idt]);
				for (i = j-1; i >= l; i--) 
				{
					if (strcmp(q[id[i]], p) <= 0)
						break;
					id[i+1] = id[i];
				}
				id[i+1] = idt;
			}
			if (jstack == 0)
				break;
			ir = istack[jstack--];
			l = istack[jstack--];
		} 
		else 
		{
			k = (l + ir) >> 1;
			SWAP(id[k], id[l+1]);
			if (strcmp(q[id[l]], q[id[ir]]) > 0) {
				SWAP(id[l], id[ir])
			}
			if (strcmp(q[id[l + 1]], q[id[ir]]) > 0) {
				SWAP(id[l + 1], id[ir])
			}
			if (strcmp(q[id[l]], q[id[l + 1]]) > 0) {
				SWAP(id[l], id[l + 1])
			}
			i = l + 1;
			j = ir;
			idt = id[l+1];
			//strcpy(c, q[idt]);
			p= q[idt];
			for (;;) 
			{
				do
					i++;
				while (strcmp(q[id[i]], p) < 0);
				do
					j--;
				while (strcmp(q[id[j]], p) > 0);
				if (j<i)
					break;
				SWAP(id[i], id[j])
			}
			id[l + 1] = id[j];
			id[j] = idt;
			jstack += 2;
			if (jstack > NSTACK)
				exit(1);
		//		error("NSTACK too small in indexx.");
			if (ir-i+1 >= j-l) 
			{
				istack[jstack] = ir;
				istack[jstack-1] = i;
				ir = j-1;
			} else 
			{
				istack[jstack] = j-1;
				istack[jstack-1] = l;
				l = i;
			}
		}
	}
	//free_ivector(istack, init, NSTACK-(1-init));
	free_ivector(istack, 1, NSTACK);
//	free_cvector(c,init,MAX_WORD_LEN-init);
}
