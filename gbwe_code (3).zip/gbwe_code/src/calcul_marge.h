/* calcul_marge.h */

#ifndef CALCUL_MARGE_H
#define CALCUL_MARGE_H

double calcul_marge(double **m02,int ligne,int colonne,double marge_l[], double marge_c[]);

#endif /* CALCUL_MARGE_H */
