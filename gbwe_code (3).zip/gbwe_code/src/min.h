/*  min.h  */
#ifndef MIN_H
#define MIN_H

double min(double a, double b);
int min_i(int a, int b);

#endif /* MIN_H */
