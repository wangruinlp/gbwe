/*   enveloppe_gauche.h   */

#ifndef ENVELOPPE_GAUCHE_H
#define ENVELOPPE_GAUCHE_H

void enveloppe_gauche(double Ae[], int lig,pilegen pile_e1,pilegen pile_e2);

#endif  /*  ENVELOPPE_GAUCHE_H */
