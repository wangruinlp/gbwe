/* instruction de debuggage */



/*  		    printf("nbcli %d \n",nbcli); */
/*  		    for(i = 0; i <nbcli ; i++) */
/*  		      { */
/*  			printf(" val [%d ] %f %f \n",i,Ae[i*2],Ae[i*2+1]); */
/*  			printf(" ind %d \n",Ax[i]); */
/*  		      } */
/*  		    getchar(); */
/*      		    printf(" nbcli apres %d \n",nbcli);  */


/*    		    printf("sommet bas %d \n",Ax[*(int *)pilegen_sommet(pile_e1)]-1);  */
/*    		    printf("sommet haut %d \n",Ax[*(int *)pilegen_sommet(pile_e2)]-1);  */


/*    			printf(">2test doublon %s ",test_doublon);  */
/*    			printf("test chaine %s \n",test_chaine);  */


/*    		    printf(" nbcli apres %d \n",nbcli); */
/*  		    printf(" polygone\n"); */
/*  		    getchar(); */

/*  		    printf("test chaine %s \n",test_chaine); */
/*    		    getchar();  */


/*  			printf("<2test doublon %s ",test_doublon); */
/*  			printf("test chaine %s \n",test_chaine); */
/*  		    printf("test chaine %s \n",test_chaine); */
/*  		    getchar(); */

/*   		    printf("nbcli avant %d \n",nbcli); */


/*     printf("cherchehb: min %d %f\n",*mini,Ae[(*mini)*2+1]); */
/*       printf("cherchehb: max %d %f\n",*maxi,Ae[(*maxi)*2+1]);  */
/*       getchar();  */

  /* printf(" max %f \n",max); 
     printf(" min %f \n",min); */

/*  	      printf("Ae 2i %d 2(i+1) %d 2i+1 %d 2(i+1)+1 %d \n",(int) (Ae[i*2]*PRECIS),(int) (Ae[(i+1)*2]*PRECIS) ,(int) (Ae[i*2+1]*PRECIS),(int) (Ae[(i+1)*2+1]*PRECIS)); */
/*  	      getchar(); */


/*    printf("ecriture matrice 0/1 : ligne cliques, colonne synonymes\n"); */
/*    affiche_temps(temps1); */
/*    affiche_temps(temps1); */

/*    printf("--> ecriture des fichiers correspondants\n"); */
/*    printf("recherche polygones convexes pour entourer les cliques\n"); */
/*    affiche_temps(temps1); */
/*    cluster(nf+1,coord.i,argv[1],ccli); */
/*    printf("lecture du fichier des cliques\n"); */
/*    printf("--> resultat : cliques %d, synonymes %d \n", coord.i, coord.j); */



/*    printf("calcul des marges\n"); */
/*    printf("matrice mv\n"); */
/*    affiche_matrice(mv,colonne,colonne); */
/*    getchar(); */
/*    printf("tridiagonalisation \n"); */
/*    printf("diagonalisation \n"); */
/*    printf("tri valeurs propres\n"); */
/*    printf("coordonnees cliques et synonymes\n"); */
/*    affiche_matrice(mv,colonne,colonne); */
/*    affiche_vecteur(d,colonne,1,0); */
/*    getchar(); */
