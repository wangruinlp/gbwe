/* produit.h */

#ifndef PRODUIT_CROISE_H
#define PRODUIT_CROISE_H

int produit_croise(double x0,double y0, double x1,double y1,double x2,double y2);

#endif   /* PRODUIT_CROISE_H  */
