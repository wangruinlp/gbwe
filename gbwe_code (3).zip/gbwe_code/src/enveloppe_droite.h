/*   enveloppe_droite.h   */

#ifndef ENVELOPPE_DROITE_H
#define ENVELOPPE_DROITE_H

void enveloppe_droite(double Ae[], int lig,pilegen pile_e1,pilegen pile_e2);

#endif  /*  ENVELOPPE_DROITE_H */
