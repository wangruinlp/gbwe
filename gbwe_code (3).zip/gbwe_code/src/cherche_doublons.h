/* cherche_doublons.h */

#ifndef CHERCHE_DOUBLONS_H
#define CHERCHE_DOUBLONS_H

int cherche_doublons(int *Ax,double *Ae,int nbcli);

#endif /* CHERCHE_DOUBLONS_H */
