#include <stdio.h>
#include <ctype.h>
void
toHref(char *t, const char *s)
{
	register char *p=s;
	register char *q=t;
	register int c;

	while((c=*p))
	{
                 //if (*p>'z' || *p<'A' || (*p>'Z' && *p<'a'))
                 if (!isalnum(c))
                 //if (*p>'z' || *p<'a')
                 {
		     if(c<0) c+=256;
                     sprintf(q,"%%%2X",c);
		     q+=3;
		     p++;
                 }
		 else
			 *q++ = *p++;
	}
	*q=0;
}
