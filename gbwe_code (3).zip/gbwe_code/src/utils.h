/** 
 * Utils
 */

/* Written January 2002 by Hyungsuk JI.  */

/* Nonzero if any of the input files are the standard input. */
//int have_read_stdin;
#ifndef Max
#define Max(A,B) ((A) > (B) ? (A) : (B))
#endif

#ifndef Min
#define Min(A,B) ((A) < (B) ? (A) : (B))
#endif

#ifndef isEqual
#define isEqual(a, b) (strcmp ((a), (b)) == 0)
#endif

#ifndef false
#define false 0
#endif

#ifndef true
#define true 1
#endif
//enum boolean{false, true};

