/**
 * ncopy(to,"string[2,3,4...", '[');
 * == copy(to,"string");
 *
 * CAUTION : this does not examine whether the length of "t" is too short or not. 
 * It might cause "Segmentation fault in case "s" does not have  "token".
 */
void ncpy (char * t, const char *s, const char v)
{
	register const char *p=s;
	register char *q=t;
	while( *p!=v &&  *p)
		*q++ = *p++;
	*q = '\0';
}
