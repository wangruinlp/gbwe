#define FILE_NOT_FOUND -1
#define NO_ENTRY -2
#define LINE_TOO_LONG -3
#define FILE_FORMAT_ERROR -4
#define FILE_ERROR -1
#define ARG_ERROR -2
#define ARG_NUM_ERROR -3
#define ALLOCATION_FAILURE -4
