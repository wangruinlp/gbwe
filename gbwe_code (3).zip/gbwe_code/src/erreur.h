/* erreur.h */

#ifndef ERREUR_H
#define ERREUR_H

void perror_and_exit(char *location);

#endif  /* ERREUR_ */
