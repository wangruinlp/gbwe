/* lecture_fichier.c */

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"taille_tampon.h"
#include "vecteur.h"
#include "lecture_fichier.h"

//#define TRACER(e) (printf("%s:%d: %s\n", __FILE__,__LINE__, #e),e)
void lecture_fichier_num(vecteur v,FILE * flot, char * sep, coord *coordi)
{
  int indice;
  int numcol;
  int *entier;
  char * p;
  char tampon[TAILLE_TAMPON];

  /* int i;
   * int n;
   */
  vecteur_mode_bavard(v,0);

  p = malloc(TAILLE_TAMPON);
  /*coordi = malloc(sizeof(struct coordi));*/
  coordi->i = 0;
  coordi->j = 0;

  indice = 0;
  while ( fgets(tampon, sizeof(tampon), flot ) != NULL )
    {
      coordi->i = coordi->i + 1;
      p = strtok(tampon, sep);
      do 
	{
	  numcol=strtol(p, NULL, 10);
	  if (numcol > coordi->j) coordi->j = numcol;
	  if ( numcol == 0 ) /* cas ligne terminee par "," */
	    {
	      p = strtok(NULL,sep);
	      continue;
	    }
	  entier = malloc(sizeof(int));
	  *entier = numcol;
	  vecteur_ecrire(v,indice,entier);

	  /* printf("%d ", numcol ); */
	  p=strtok(NULL, sep);
	  indice++;
	} while ( p!=NULL );
      /* printf("\n"); */
      entier = malloc(sizeof(int));
      *entier = -1;
      vecteur_ecrire(v,indice,entier);
      indice++;
    }	
  /* n = vecteur_nombre_elements(v);
   * for (i = 0; i < n ; i++)
   * printf(" - v[%d] : %d\n",i,*(int *) vecteur_lire(v,i));
   */
}

