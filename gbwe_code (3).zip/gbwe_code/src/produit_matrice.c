/* produit_matrice.c */

#include "produit_matrice.h"
#include "nrutils.h"

/******************************************************************/
/* fonction de produit de transposee de matrice par la matrice    */
/******************************************************************/

void produit_matrice(double **mv,double **m01,int ligne,int colonne)
{
  int ii,jj,k;
  double valeur;

  /* produit gauche d'une matrice par sa transposee */

  for( ii = 1 ; ii <= colonne ; ii++ )
    {
      for( jj = 1 ; jj <= ii ; jj++ )
	{
	  valeur = 0;
	  for( k = 1 ; k <= ligne ; k ++ )
	    {
	      valeur = valeur + m01[k][jj]*m01[k][ii];
	    }
	  mv[ii][jj] = valeur;
	  if ( ii != jj )
	    {
	      mv[jj][ii] = valeur;
	    }
	}
    }
}







