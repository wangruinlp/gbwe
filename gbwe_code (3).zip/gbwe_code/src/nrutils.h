/* nrutils.h */
#ifndef NR_UTILS_H
#define NR_UTILS_H

double **dmatrix(long nrl, long nrh, long ncl, long nch);

#endif /* NR_UTILS_H */
