void
repchr(char *t, const char *s, char old, char new)
{
	register const char *p=s;
	register char *q=t;
	while(*p)
	{
		if(*p == old)
		{
			*q++ = new;
			p++;
		}
		else
			*q++ = *p++;
	}
	*q=0;
}
