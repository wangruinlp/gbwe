#define MAXKEYLEN 16
#define MAXQLEN 350
struct Query 
{
	char key[MAXKEYLEN];
	char value[MAXQLEN];
};
typedef struct Query Query;
