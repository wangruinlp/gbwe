#include "utils.h"
#include "query.h"
int getQueries(Query *qry, const char *s);
