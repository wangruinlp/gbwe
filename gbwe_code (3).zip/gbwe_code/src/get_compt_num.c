#include <stdio.h>
#include <stdlib.h>
#include <sys/file.h>
#include <time.h>
#include <sys/time.h>
char *
get_compt_num(char *hname, const char *controldir)
{
	FILE* fp;
	register char str[512]; 
	register int filenum=0;
        time_t tim;
        struct tm *ttim;
        struct timespec thistime;

        sprintf(str,"%scompteur",controldir);
	if((fp=fopen(str,"r+"))==NULL)
		return NULL;
	flock(fp->_file,LOCK_EX | LOCK_NB);
	//flock(fp->_file,LOCK_EX);
        //if((fp=dicofopen(str,"r+"))==NULL)
        //fseek(fcomp,0,0);
	fgetline(str,64,fp);
	filenum=atoi(str);
	filenum+=1;
        fseek(fp,0,0);
        fprintf(fp,"%09d\n",filenum);
    	flock(fp->_file, LOCK_UN);
    	close(fp);


        tim=time(NULL);
        ttim=localtime(&tim);
	clock_gettime(CLOCK_REALTIME,&thistime);
        sprintf(hname,"%2.2d%2.2d%2.2d%2.2d_%08X_%u",((*ttim).tm_year % 100),((*ttim).tm_mon+1),(*ttim).tm_mday,(*ttim).tm_hour,filenum,thistime.tv_sec);

       return hname;

	
}
